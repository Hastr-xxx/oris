﻿namespace CustomHttpServer.Framework.Core
{
    public abstract class ControllerBase { }
}